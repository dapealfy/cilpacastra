

<?php $__env->startSection('title', 'Album'); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <div class="content-header-left col-md-6 col-12breadcrumb-new">
    </div>
    <div class="content-header-right col-md-6 col-12 text-right">
        <div class="btn-group float-md-right">
            <button class="btn btn-warning rounded-0" id="createSongButton" type="button">Tambah</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mt-2">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">List Lagu</h4>
                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-content collapse show">
                <div class="card-body card-dashboard">
                    <p class="card-text">Berikut adalah list dari beberapa Lagu dari Album <?php echo e($album->album_name); ?></p>
                    <table class="table table-responsive d-xl-table datatable w-100">
                        <thead>
                            <tr>
                                <th>Judul Lagu</th>
                                <th>Artis</th>
                                <th>Not Dasar</th>
                                <th width="10%" class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $album->songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <a href="<?php echo e(route('song.show', $song->id)); ?>" target="_blank">
                                            <?php echo e($song->index != null ? $song->index . '.' : ''); ?> <?php echo e($song->title); ?>

                                        </a>
                                    </td>
                                    <td><?php echo e($song->artist); ?></td>
                                    <td><?php echo e($song->basic_notes); ?></td>
                                    <td>
                                        <div class="btn-group ">
                                            <a href="<?php echo e(route('song.show', $song->id)); ?>" class="btn btn-sm btn-warning">Lihat</a>
                                            <button class="btn btn-sm btn-info editSongButton" value="<?php echo e($song->id); ?>">Edit
                                            </button>
                                            <button class="btn btn-sm btn-danger deleteSongButton" value="<?php echo e($song->id); ?>">Hapus
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="createSongModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Tambah Lagu</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="<?php echo e(route('song.store')); ?>" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="">Judul Lagu (Default)</label>
                        <input type="text" name="title" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="">Judul Lagu (Bahasa Inggris)</label>
                        <input type="text" name="en_title" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="">Indeks</label>
                        <input type="number" name="index" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="">Artis</label>
                        <input type="text" name="artist" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="">Album</label>
                        <select name="album_id" class="form-control album-select">
                            <option value="<?php echo e($album->id); ?>"><?php echo e($album->album_name); ?></option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Thumbnail</label>
                        <input type="file" name="thumbnail" class="form-control" accept="image/*">
                    </div>
                    <div class="form-group">
                        <label for="">Not Dasar</label>
                        <input type="text" name="basic_notes" placeholder="ex. C 4/4" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="">Cerita</label>
                        <textarea name="story" class="form-control" required rows="5">
                        </textarea>
                    </div>
                    <div class="form-group">
                        <label for="">Not Balok</label>
                        <input type="file" name="musical_notes" class="form-control" accept="image/*">
                    </div>
                    <div class="form-group">
                        <label for="">Musik</label>
                        <input type="file" name="music" class="form-control" accept="audio/*">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-warning submit-button">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="editSongModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Edit Lagu</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="" id="editSongForm" method="post">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("PUT"); ?>
                    <div class="form-group">
                        <label for="">Judul Lagu (Default)</label>
                        <input type="text" name="title" class="form-control" id="editSongTitle" required>
                    </div>
                    <div class="form-group">
                        <label for="">Judul Lagu (Bahasa Inggris)</label>
                        <input type="text" name="en_title" class="form-control" id="editSongEnTitle" required>
                    </div>
                    <div class="form-group">
                        <label for="">Indeks</label>
                        <input type="number" name="index" class="form-control" id="editSongIndex" required>
                    </div>
                    <div class="form-group">
                        <label for="">Artis</label>
                        <input type="text" name="artist" class="form-control" id="editSongArtist" required>
                    </div>
                    <div class="form-group">
                        <label for="">Album</label>
                        <select name="album_id" class="form-control album-select" id="editSongAlbumId">
                            <option value="<?php echo e($album->id); ?>"><?php echo e($album->album_name); ?></option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Thumbnail</label>
                        <input type="file" name="thumbnail" class="form-control" accept="image/*">
                        <small class="text-danger">*Isi jika ingin mengubah thumbnail</small>
                    </div>
                    <div class="form-group">
                        <label for="">Not Dasar & Birama</label>
                        <input type="text" name="basic_notes" placeholder="ex. C 4/4" class="form-control" id="editSongBasicNotes" required>
                    </div>
                    <div class="form-group">
                        <label for="">Cerita</label>
                        <textarea type="text" name="story" class="form-control" required rows="5" id="editSongStory">
                        </textarea>
                    </div>
                    <div class="form-group">
                        <label for="">Not Balok</label>
                        <input type="file" name="musical_notes" class="form-control" accept="image/*">
                    </div>
                    <div class="form-group">
                        <label for="">Musik</label>
                        <input type="file" name="music" class="form-control" accept="audio/*">
                        <small class="text-danger">*Isi jika ingin mengubah file musik</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-warning submit-button">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="deleteSongModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Yakin ingin menghapus Lagu?</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="" id="deleteSongForm" method="post">
                <div class="modal-footer">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("DELETE"); ?>
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-danger">Ya, Hapus</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(".album-select").select2({
            width: '100%'
        });
        $(document).on("click", "#createSongButton", function ()
        {
            $("#createSongModal").modal();
        });
        $(document).on("click", ".editSongButton", function()
        {
            let id = $(this).val();

            $.ajax(
            {
                method: "GET",
                url: "<?php echo e(route('song.index')); ?>/" + id + "/edit"
            }).done(function (response)
            {
                $("#editSongTitle").val(response.title);
                $("#editSongEnTitle").val(response.en_title);
                $("#editSongIndex").val(response.index);
                $("#editSongArtist").val(response.artist);
                $("#editSongBasicNotes").val(response.basic_notes);
                $("#editSongAlbumId option[value='" + response.album_id + "']").attr("select", true);
                $("#editSongStory").text(response.story);
                $("#editSongForm").attr("action", "<?php echo e(route('song.index')); ?>/" + id);
                $("#editSongModal").modal();
            })
        });
        $(document).on("click", ".deleteSongButton", function()
        {
            let id = $(this).val();

            $("#deleteSongForm").attr("action", "<?php echo e(route('song.index')); ?>/" + id)
            $("#deleteSongModal").modal();
        });
        $(".submit-button").on("submit", function(){
            $(".submit-button").attr("disabled", true);
            setInterval(function() {
                i = ++i % 4;
                $(".submit-button").text("Diproses"+Array(i+1).join("."));
            }, 1000);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u711889996/domains/demibangsa.com/public_html/lagu-sion/server/resources/views/dashboard/album/show.blade.php ENDPATH**/ ?>