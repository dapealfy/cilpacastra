

<?php $__env->startSection('title', 'Audio Book'); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <div class="content-header-left col-md-6 col-12 breadcrumb-new">
    </div>
    <div class="content-header-right col-md-6 col-12 text-right">
        <div class="btn-group float-md-right">
            <button class="btn btn-warning rounded-0" id="createAudioBookPartButton" type="button">Tambah</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mt-2">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">List Audio Book Part</h4>
                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                        <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                        <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                        <li><a data-action="close"><i class="ft-x"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-content collapse show">
                <div class="card-body card-dashboard">
                    <p class="card-text">Berikut adalah list dari beberapa Audio Book Part dari Audio Book <?php echo e($audio_book->title); ?></p>
                    <table class="table table-responsive d-xl-table datatable w-100">
                        <thead>
                            <tr>
                                <th>Nama Audio Book Part</th>
                                <th>Durasi</th>
                                <th>Teks</th>
                                <th width="10%" class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $audio_book->parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audio_book_part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <a href="<?php echo e($audio_book_part->music); ?>" target="_blank">
                                            <?php echo e($audio_book_part->title); ?>

                                        </a>
                                    </td>
                                    <td><?php echo e($audio_book_part->duration); ?></td>
                                    <td>
                                        <div style="height: 128px; overflow-y: scroll; ">
                                            <pre style="white-space: pre-wrap; white-space: -moz-pre-wrap; white-space: -pre-wrap; white-space: -o-pre-wrap; word-wrap: break-word; background: none; font-size: 14px"><?php echo e($audio_book_part->lyrics); ?></pre>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <button class="btn btn-sm btn-info editAudioBookPartButton" value="<?php echo e($audio_book_part->id); ?>">Edit
                                            </button>
                                            <button class="btn btn-sm btn-danger deleteAudioBookPartButton" value="<?php echo e($audio_book_part->id); ?>">Hapus
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="createAudioBookPartModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Tambah Audio Book</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="<?php echo e(route('audio-book-part.store')); ?>" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="audio_book_id" value="<?php echo e($audio_book->id); ?>">
                    <div class="form-group">
                        <label for="">Nama Audio Book Part</label>
                        <input type="text" name="title" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="">Teks</label>
                        <textarea name="lyrics" class="form-control" required rows="5"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="">File</label>
                        <input type="file" name="music" class="form-control" accept="audio/*">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-warning">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="editAudioBookPartModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Edit Audio Book</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="" id="editAudioBookPartForm" method="post">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("PUT"); ?>
                    <input type="hidden" name="audio_book_id" value="<?php echo e($audio_book->id); ?>">
                    <div class="form-group">
                        <label for="">Judul Audio Book</label>
                        <input type="text" name="title" class="form-control" id="editAudioBookPartTitle" required>
                    </div>
                    <div class="form-group">
                        <label for="">Teks</label>
                        <textarea name="lyrics" class="form-control" rows="5" id="editAudioBookPartLyrics" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="">File</label>
                        <input type="file" name="file" class="form-control" accept="audio/*">
                        <small class="text-danger">*Isi jika ingin mengubah musik</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-warning">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="deleteAudioBookPartModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Yakin ingin menghapus Audio Book?</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="" id="deleteAudioBookPartForm" method="post">
                <div class="modal-footer">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("DELETE"); ?>
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-danger">Ya, Hapus</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).on("click", "#createAudioBookPartButton", function ()
        {
            $("#createAudioBookPartModal").modal();
        });
        $(document).on("click", ".editAudioBookPartButton", function()
        {
            let id = $(this).val();

            $.ajax(
            {
                method: "GET",
                url: "<?php echo e(route('audio-book-part.index')); ?>/" + id + "/edit"
            }).done(function (response)
            {
                console.log(response);
                $("#editAudioBookPartTitle").val(response.title);
                $("#editAudioBookPartLyrics").text(response.lyrics);
                $("#editAudioBookPartForm").attr("action", "<?php echo e(route('audio-book-part.index')); ?>/" + id)
                $("#editAudioBookPartModal").modal();
            })
        });
        $(document).on("click", ".deleteAudioBookPartButton", function()
        {
            let id = $(this).val();

            $("#deleteAudioBookPartForm").attr("action", "<?php echo e(route('audio-book-part.index')); ?>/" + id)
            $("#deleteAudioBookPartModal").modal();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u711889996/domains/demibangsa.com/public_html/lagu-sion/server/resources/views/dashboard/audio_book/show.blade.php ENDPATH**/ ?>