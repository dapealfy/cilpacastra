

<?php $__env->startSection('title', 'User'); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <div class="content-header-left col-md-6 col-12 breadcrumb-new">
    </div>
    <div class="content-header-right col-md-6 col-12">
        <div class="btn-group float-md-right">
            <button class="btn btn-warning rounded-0" id="createUserButton" type="button">Tambah</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mt-2">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">List Admin</h4>
                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                        <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                        <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                        <li><a data-action="close"><i class="ft-x"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-content collapse show">
                <div class="card-body card-dashboard">
                    <table class="table table-responsive d-xl-table datatable w-100">
                        <thead>
                            <tr>
                                <th>Avatar</th>
                                <th>Nama</th>
                                <th>Username</th>
                                <th width="10%" class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <a href="<?php echo e($user->avatar); ?>" target="_blank">
                                            <img src="<?php echo e($user->avatar); ?>"  alt="" style="width: auto; height: 100px;">
                                        </a>
                                    </td>
                                    <td><?php echo e($user->name ?? '-'); ?></td>
                                    <td><?php echo e($user->username ?? '-'); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <button class="btn btn-sm btn-info editUserButton" value="<?php echo e($user->id); ?>">Edit
                                            </button>
                                            <button class="btn btn-sm btn-danger deleteUserButton" value="<?php echo e($user->id); ?>">Hapus
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="createUserModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Tambah User</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="<?php echo e(route('user.store')); ?>" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="">Avatar</label>
                        <br>
                        <img src="/app-assets/images/ico/default.png" class="img-preview" style="width: auto; height: 128px;">
                        <br>
                        <input type="file" name="avatar" class="form-control mt-1" accept="image/*">
                    </div>
                    <div class="form-group">
                        <label for="">Nama</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="">Username</label>
                        <input type="text" name="username" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="">Password</label>
                        <input type="text" name="password" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-warning submit-button">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="editUserModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Edit User</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="" id="editUserForm" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("PUT"); ?>
                    <div class="form-group">
                        <label for="">Avatar</label>
                        <br>
                        <img src="/app-assets/images/ico/default.png" class="img-preview" style="width: auto; height: 128px;">
                        <br>
                        <input type="file" name="avatar" class="form-control" accept="image/*" id="editAvatar">
                    </div>
                    <div class="form-group">
                        <label for="">Nama</label>
                        <input type="text" name="name" class="form-control" required id="editName">
                    </div>
                    <div class="form-group">
                        <label for="">Username</label>
                        <input type="text" name="username" class="form-control" required id="editUsername">
                    </div>
                    <div class="form-group">
                        <label for="">Password</label>
                        <input type="text" name="password" class="form-control">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-warning submit-button">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="deleteUserModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Yakin ingin menghapus data User?</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="" id="deleteUserForm" method="post">
                <div class="modal-footer">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("DELETE"); ?>
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-danger">Ya, Hapus</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                
                reader.onload = function(e) {
                    $('.img-preview').attr('src', e.target.result);
                }
                
                reader.readAsDataURL(input.files[0]); // convert to base64 string
            }
        }

        $("#editAvatar").change(function() {
            readURL(this);
        });
        $(".user-select").select2({
            width: '100%'
        });
        $(document).on("click", "#createUserButton", function ()
        {
            $(".img-preview").attr("src", "/app-assets/images/ico/default.png");
            $("#createUserModal").modal();
        });
        $(document).on("click", ".editUserButton", function()
        {
            let id = $(this).val();
            $(".img-preview").attr("src", "/app-assets/images/ico/default.png");
            $.ajax(
            {
                method: "GET",
                url: "<?php echo e(route('user.index')); ?>/" + id + "/edit"
            }).done(function (response)
            {
                if(response.avatar != null && response.avatar != '')
                {
                    $(".img-preview").attr("src", response.avatar);
                }
                $("#editName").val(response.name);
                $("#editUsername").val(response.username);
                $("#editUserForm").attr("action", "<?php echo e(route('user.index')); ?>/" + id);
                $("#editUserModal").modal();
            })
        });
        $(document).on("click", ".deleteUserButton", function()
        {
            let id = $(this).val();

            $("#deleteUserForm").attr("action", "<?php echo e(route('user.index')); ?>/" + id)
            $("#deleteUserModal").modal();
        });
        $(".submit-button").on("submit", function(){
            $(".submit-button").attr("disabled", true);
            setInterval(function() {
                i = ++i % 4;
                $(".submit-button").text("Diproses"+Array(i+1).join("."));
            }, 1000);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u711889996/domains/demibangsa.com/public_html/lagu-sion/server/resources/views/dashboard/user/index.blade.php ENDPATH**/ ?>