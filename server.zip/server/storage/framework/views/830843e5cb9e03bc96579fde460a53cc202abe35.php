

<?php $__env->startSection('title', 'Banner'); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <div class="content-header-left col-md-6 col-12 breadcrumb-new">
    </div>
    <div class="content-header-right col-md-6 col-12 text-right">
        <div class="btn-group">
            <button class="btn btn-warning rounded-0" id="createBannerButton" type="button">Tambah</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mt-2">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">List Banner</h4>
                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                        <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                        <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                        <li><a data-action="close"><i class="ft-x"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-content collapse show">
                <div class="card-body card-dashboard">
                    <table class="table table-responsive datatable w-100">
                        <thead>
                            <tr>
                                <th>Gambar</th>
                                <th>Author</th>
                                <th>Judul</th>
                                <th>Link</th>
                                <th>Tipe</th>
                                <th>Deskripsi</th>
                                <th width="10%">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <a href="<?php echo e($banner->img); ?>" target="_blank">
                                            <img src="<?php echo e($banner->img); ?>"  alt="" style="width: auto; height: 100px;">
                                        </a>
                                    </td>
                                    <td><?php echo e($banner->author->name); ?></td>
                                    <td><?php echo e($banner->title); ?></td>
                                    <?php if($banner->link != null): ?>
                                        <td>
                                            <a href="<?php echo e($banner->link); ?>"><?php echo e($banner->link); ?></a>
                                        </td>
                                    <?php else: ?>
                                        <td>-</td>
                                    <?php endif; ?>
                                    <td class="text-capitalize text-nowrap"><?php echo e($banner->type); ?></td>
                                    <td><?php echo e($banner->message); ?></td>
                                    <td>
                                        <div class="btn-group" style="min-width: 9rem !important">
                                            <button class="btn btn-sm btn-info editBannerButton" value="<?php echo e($banner->id); ?>">Edit
                                            </button>
                                            <button class="btn btn-sm btn-danger deleteBannerButton" value="<?php echo e($banner->id); ?>">Hapus
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="createBannerModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Tambah Banner</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="<?php echo e(route('banner.store')); ?>" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="">Gambar</label>
                        <input type="file" name="img" class="form-control" accept="image/*">
                    </div>
                    <div class="form-group">
                        <label for="">Judul</label>
                        <input type="text" name="title" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="">Link</label>
                        <div class="create_dynamic_field">
                            <div class="row mb-1 additional-category">
                                <div class="col-4">
                                    <input type="text" name="judul[]" placeholder="Masukkan judul" class="form-control judul_list" required/>
                                </div>
                                <div class="col-4">
                                    <input type="text" name="link[]" placeholder="Masukkan link" class="form-control link_list" required/>
                                </div>
                                <div class="col-4">
                                    <button type="button" name="add" class="btn btn-success create_add" style="color:white;">
                                        <i class="la la-plus"></i>
                                    </button>
                                    <button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">
                                        <i class="la la-times"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="">Tipe</label>
                        <select name="type" class="form-control" required>
                            <option value="one click">One Click</option>
                            <option value="by date">By Date</option>
                            <option value="unlimited">Unlimited</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Deskripsi</label>
                        <textarea name="message" class="form-control" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="">Tanggal Expired</label>
                        <input type="date" name="deleted_at" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-warning submit-button">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="editBannerModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Edit Banner</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="" id="editBannerForm" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("PUT"); ?>
                    <div class="form-group">
                        <img style="height: 100px; width: auto;" id="editThumbnailPreview">
                    </div>
                    <div class="form-group">
                        <label for="">Gambar</label>
                        <input type="file" name="img" class="form-control" accept="image/*" id="editThumbnail">
                    </div>
                    <div class="form-group">
                        <label for="">Judul</label>
                        <input type="text" name="title" class="form-control" id="editTitle" required>
                    </div>
                    <div class="form-group">
                        <label for="">Link</label>
                        <div class="create_dynamic_field" id="editLinks">
                            
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="">Tipe</label>
                        <select name="type" class="form-control" id="editType" required>
                            <option value="one click">One Click</option>
                            <option value="by date">By Date</option>
                            <option value="unlimited">Unlimited</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Deskripsi</label>
                        <textarea name="message" class="form-control" id="editMessage" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="">Tanggal Expired</label>
                        <input type="date" name="deleted_at" class="form-control" id="editDeletedAt" required>
                    </div>
    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-warning submit-button">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="deleteBannerModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Yakin ingin menghapus data Banner?</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="" id="deleteBannerForm" method="post">
                <div class="modal-footer">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("DELETE"); ?>
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-danger">Ya, Hapus</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                
                reader.onload = function(e) {
                    $('#editThumbnailPreview').attr('src', e.target.result);
                }
                
                reader.readAsDataURL(input.files[0]); // convert to base64 string
            }
        }
        
        var i=1;
        $(document).on('click', '.create_add', function()
        {
            i++;
            $(this).closest('.create_dynamic_field').append('<div class="row mb-1 additional-category"><div class="col-4"><input type="text" name="judul[]" placeholder="Masukkan judul" class="form-control judul_list"/></div><div class="col-4"><input type="text" name="link[]" placeholder="Masukkan link" class="form-control link_list"/></div><div class="col-4 col-sm-2"><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove"><i class="la la-times"></i></button></div></div>');
        });
        
        $(document).on('click', '.btn_remove', function()
        {
            let title = $(this).closest('.additional-category').find(".judul_list");
            let link = $(this).closest('.additional-category').find(".link_list");
            let addButton = $(this).closest('.additional-category').find(".create_add");
            if(addButton[0])
            {
                if((link.val() != null && link.val() != '') || (title.val() != null && title.val() != ''))
                {
                    if (confirm('Apakah Anda yakin ingin menghapus link?')) {
                        // Save it!
                        console.log('removed');
                        title.val(null);
                        link.val(null);                    
                        
                    } else {
                        // Do nothing!
                        console.log('cancelled');
                    }
                }else{
                    title.val(null);
                    link.val(null); 
                }
            }else{
                if((link.val() != null && link.val() != '') || (title.val() != null && title.val() != ''))
                {
                    if (confirm('Apakah Anda yakin ingin menghapus link?')) {
                        // Save it!
                        console.log('removed');
                        $(this).closest('.additional-category').remove();
                    } else {
                        // Do nothing!
                        console.log('cancelled');
                    }
                }else{
                    $(this).closest('.additional-category').remove();
                }
            }
        });

        $("#editThumbnail").change(function() {
            readURL(this);
        });
        
        $(".banner-select").select2({
            width: '100%'
        });
        $(document).on("click", "#createBannerButton", function ()
        {
            $("#createBannerModal").modal();
        });
        $(document).on("click", ".editBannerButton", function()
        {
            let id = $(this).val();

            $.ajax(
            {
                method: "GET",
                url: "<?php echo e(route('banner.index')); ?>/" + id + "/edit"
            }).done(function (response)
            {
                console.log(response);
                $("#editThumbnailPreview").attr("src", response.img);
                $("#editTitle").val(response.title);
                $("#editMessage").val(response.message);
                $("#editLinks").empty();
                if(response.links.length != 0)
                {
                    $.each( response.links, function( key, value ) {
                        if(key == 0)
                        {
                            $("#editLinks").append('<div class="row mb-1 additional-category"> <div class="col-4"> <input type="text" name="judul[]" placeholder="Masukkan judul" class="form-control judul_list" value="'+value.title+'" required/> </div> <div class="col-4"> <input type="text" name="link[]" placeholder="Masukkan link" class="form-control link_list" value="'+value.link+'" required/> </div> <div class="col-4"> <button type="button" name="add" class="btn btn-success create_add" style="color:white;"><i class="la la-plus"></i></button> <button type="button" name="remove" id="" class="btn btn-danger btn_remove"><i class="la la-times"></i></button></div> </div>')
                        }else{
                            $("#editLinks").append('<div class="row mb-1 additional-category"><div class="col-4"><input type="text" name="judul[]" placeholder="Masukkan judul" class="form-control judul_list" value="'+value.title+'" /></div><div class="col-4"><input type="text" name="link[]" placeholder="Masukkan link" class="form-control link_list" value="'+value.link+'" /></div><div class="col-4 col-sm-2"><button type="button" name="remove"  class="btn btn-danger  btn_remove"><i class="la la-times"></i></button></div></div>');
                        }
                    });
                }else{
                    $("#editLinks").append('<div class="row mb-1 additional-category"> <div class="col-4"> <input type="text" name="judul[]" placeholder="Masukkan judul" class="form-control judul_list" value="" required/> </div> <div class="col-4"> <input type="text" name="link[]" placeholder="Masukkan link" class="form-control link_list" value="" required/> </div> <div class="col-4"> <button type="button" name="add" class="btn btn-success create_add" style="color:white;"><i class="la la-plus"></i></button> <button type="button" name="remove" id="" class="btn btn-danger btn_remove"><i class="la la-times"></i></button></div> </div>');
                }
                $("#editDeletedAt").val(response.deleted_at);
                $("#editType").val(response.type).trigger("change");
                $("#editBannerForm").attr("action", "<?php echo e(route('banner.index')); ?>/" + id);
                $("#editBannerModal").modal();
            })
        });
        $(document).on("click", ".deleteBannerButton", function()
        {
            let id = $(this).val();

            $("#deleteBannerForm").attr("action", "<?php echo e(route('banner.index')); ?>/" + id)
            $("#deleteBannerModal").modal();
        });
        
        $("form").on("submit", function(){
            $(".submit-button").prop("disabled", true);
            var i = 1;
            $(".submit-button").text("Diproses"+Array(i).join("."));
            setInterval(function() {
                i = ++i % 4;
                $(".submit-button").text("Diproses"+Array(i+1).join("."));
            }, 1000);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u711889996/domains/demibangsa.com/public_html/lagu-sion/server/resources/views/dashboard/banner/index.blade.php ENDPATH**/ ?>