<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DataBidangHotel extends Model
{
    protected $guarded = [
        'id'
    ];
}
