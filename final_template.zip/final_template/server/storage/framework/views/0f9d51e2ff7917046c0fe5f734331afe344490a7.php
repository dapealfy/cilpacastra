<?php $__env->startSection('title', 'Lagu'); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <div class="content-header-left col-md-6 col-12 breadcrumb-new">
    </div>
    <div class="content-header-right col-md-6 col-12 text-right">
        <div class="btn-group">
            <button class="btn btn-warning rounded-0" id="createSongButton" type="button">Tambah</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mt-2">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">List Lagu</h4>
                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                        <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                        <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                        <li><a data-action="close"><i class="ft-x"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-content collapse show">
                <div class="card-body card-dashboard">
                    <table class="table table-responsive d-xl-table datatable w-100">
                        <thead>
                            <tr>
                                <th>Judul Lagu</th>
                                <th>Artis</th>
                                <th>Album</th>
                                <th>Not Dasar</th>
                                <th width="10%" class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><span class="d-none"><?php echo e(str_pad($song->index, 10, "0", STR_PAD_LEFT)); ?> | </span><?php echo e($song->index != null ? $song->index . '.' : ''); ?> <?php echo e($song->title); ?></td>
                                    <td><?php echo e($song->artist); ?></td>
                                    <td><?php echo e($song->album->album_name ?? ''); ?></td>
                                    <td><?php echo e($song->basic_notes); ?></td>
                                    <td>
                                        <div class="btn-group ">
                                            <a href="<?php echo e(route('song.show', $song->id)); ?>" class="btn btn-sm btn-warning">Lihat</a>
                                            <button class="btn btn-sm btn-info editSongButton" value="<?php echo e($song->id); ?>">Edit
                                            </button>
                                            <button class="btn btn-sm btn-danger deleteSongButton" value="<?php echo e($song->id); ?>">Hapus
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="createSongModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Tambah Lagu</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="<?php echo e(route('song.store')); ?>" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="">Judul Lagu</label>
                        <input type="text" name="title" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="">Indeks</label>
                        <input type="number" name="index" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="">Artis</label>
                        <input type="text" name="artist" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="">Album</label>
                        <select name="album_id" class="form-control album-select">
                            <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($album->id); ?>"><?php echo e($album->album_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Thumbnail</label>
                        <input type="file" name="thumbnail" class="form-control" accept="image/*" required>
                    </div>
                    <div class="form-group">
                        <label for="">Not Dasar</label>
                        <input type="text" name="basic_notes" placeholder="ex. C 4/4" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="">Cerita</label>
                        <textarea name="story" class="form-control" required rows="5" required>
                        </textarea>
                    </div>
                    <div class="form-group">
                        <label for="">Link Cerita</label>
                        <div class="create_dynamic_field">
                            <div class="row mb-1 additional-category">
                                <div class="col-4">
                                    <input type="text" name="judul[]" placeholder="Masukkan judul" class="form-control judul_list" required/>
                                </div>
                                <div class="col-4">
                                    <input type="text" name="link[]" placeholder="Masukkan link" class="form-control link_list" required/>
                                </div>
                                <div class="col-4">
                                    <button type="button" name="add" class="btn btn-success create_add" style="color:white;">
                                        <i class="la la-plus"></i>
                                    </button>
                                    <button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">
                                        <i class="la la-times"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="">Not Balok</label>
                        <input type="file" name="musical_notes" class="form-control" accept="image/*" required>
                    </div>
                    <div class="form-group">
                        <label for="">Reff</label>
                        <textarea name="reff" class="form-control" required rows="5"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="">Kategori</label>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="category_ids[]" value="<?php echo e($category->id); ?>">
                                <label class="form-check-label">
                                    <?php echo e($category->name); ?>

                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-warning submit-button">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="editSongModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Edit Lagu</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="" id="editSongForm" method="post">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("PUT"); ?>
                    <div class="form-group">
                        <label for="">Judul Lagu</label>
                        <input type="text" name="title" class="form-control" id="editSongTitle" required>
                    </div>
                    <div class="form-group">
                        <label for="">Indeks</label>
                        <input type="number" name="index" class="form-control" id="editSongIndex" required>
                    </div>
                    <div class="form-group">
                        <label for="">Artis</label>
                        <input type="text" name="artist" class="form-control" id="editSongArtist" required>
                    </div>
                    <div class="form-group">
                        <label for="">Album</label>
                        <select name="album_id" class="form-control album-select" id="editSongAlbumId">
                            <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($album->id); ?>"><?php echo e($album->album_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Thumbnail</label>
                        <input type="file" name="thumbnail" class="form-control" accept="image/*">
                        <small class="text-danger">*Isi jika ingin mengubah thumbnail</small>
                    </div>
                    <div class="form-group">
                        <label for="">Not Dasar & Birama</label>
                        <input type="text" name="basic_notes" placeholder="ex. C 4/4" class="form-control" id="editSongBasicNotes" required>
                    </div>
                    <div class="form-group">
                        <label for="">Cerita</label>
                        <textarea type="text" name="story" class="form-control" required rows="5" id="editSongStory">
                        </textarea>
                    </div>
                    <div class="form-group">
                        <label for="">Link Cerita</label>
                        <div class="create_dynamic_field" id="editLinks">
                            
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="">Not Balok</label>
                        <input type="file" name="musical_notes" class="form-control" accept="image/*">
                    </div>
                    <div class="form-group">
                        <label for="">Reff</label>
                        <textarea name="reff" class="form-control" required rows="5" id="editSongReff"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="">Kategori</label>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check">
                                <input class="form-check-input edit-category" type="checkbox" name="category_ids[]" value="<?php echo e($category->id); ?>">
                                <label class="form-check-label" for="defaultCheck1">
                                    <?php echo e($category->name); ?>

                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!--<div class="form-group">-->
                    <!--    <label for="">Musik</label>-->
                    <!--    <input type="file" name="music" class="form-control" accept="audio/*">-->
                    <!--    <small class="text-danger">*Isi jika ingin mengubah file musik</small>-->
                    <!--</div>-->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-warning submit-button">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="deleteSongModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Yakin ingin menghapus Lagu?</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="" id="deleteSongForm" method="post">
                <div class="modal-footer">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("DELETE"); ?>
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-danger">Ya, Hapus</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(".album-select").select2({
            width: '100%'
        });
        var i=1;
        $(document).on('click', '.create_add', function()
        {
            i++;
            $(this).closest('.create_dynamic_field').append('<div class="row mb-1 additional-category"><div class="col-4"><input type="text" name="judul[]" placeholder="Masukkan judul" class="form-control judul_list"/></div><div class="col-4"><input type="text" name="link[]" placeholder="Masukkan link" class="form-control link_list"/></div><div class="col-4 col-sm-2"><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove"><i class="la la-times"></i></button></div></div>');
        });
        $(document).on('click', '.btn_remove', function()
        {
            let title = $(this).closest('.additional-category').find(".judul_list");
            let link = $(this).closest('.additional-category').find(".link_list");
            let addButton = $(this).closest('.additional-category').find(".create_add");
            if(addButton[0])
            {
                if((link.val() != null && link.val() != '') || (title.val() != null && title.val() != ''))
                {
                    if (confirm('Apakah Anda yakin ingin menghapus link?')) {
                        // Save it!
                        console.log('removed');
                        title.val(null);
                        link.val(null);                    
                        
                    } else {
                        // Do nothing!
                        console.log('cancelled');
                    }
                }else{
                    title.val(null);
                    link.val(null); 
                }
            }else{
                if((link.val() != null && link.val() != '') || (title.val() != null && title.val() != ''))
                {
                    if (confirm('Apakah Anda yakin ingin menghapus link?')) {
                        // Save it!
                        console.log('removed');
                        $(this).closest('.additional-category').remove();
                    } else {
                        // Do nothing!
                        console.log('cancelled');
                    }
                }else{
                    $(this).closest('.additional-category').remove();
                }
            }
        });
        $(document).on("click", "#createSongButton", function ()
        {
            $("#createSongModal").modal();
        });
        $(document).on("click", ".editSongButton", function()
        {
            let id = $(this).val();
            $(".edit-category").prop("checked", false);
            $.ajax(
            {
                method: "GET",
                url: "<?php echo e(route('song.index')); ?>/" + id + "/edit"
            }).done(function (response)
            {
                $("#editSongTitle").val(response.title);
                $("#editSongIndex").val(response.index);
                $("#editSongArtist").val(response.artist);
                $("#editSongBasicNotes").val(response.basic_notes);
                $("#editSongAlbumId option[value='" + response.album_id + "']").prop("selected", true);
                $("#editSongStory").text(response.story);
                $("#editLinks").empty();
                if(response.link_stories.length != 0)
                {
                    $.each( response.link_stories, function( key, value ) {
                        if(key == 0)
                        {
                            $("#editLinks").append('<div class="row mb-1 additional-category"> <div class="col-4"> <input type="text" name="judul[]" placeholder="Masukkan judul" class="form-control judul_list" value="'+value.title+'" required/> </div> <div class="col-4"> <input type="text" name="link[]" placeholder="Masukkan link" class="form-control link_list" value="'+value.link+'" required/> </div> <div class="col-4"> <button type="button" name="add" class="btn btn-success create_add" style="color:white;"><i class="la la-plus"></i></button> <button type="button" name="remove" id="" class="btn btn-danger btn_remove"><i class="la la-times"></i></button></div> </div>')
                        }else{
                            $("#editLinks").append('<div class="row mb-1 additional-category"><div class="col-4"><input type="text" name="judul[]" placeholder="Masukkan judul" class="form-control judul_list" value="'+value.title+'" /></div><div class="col-4"><input type="text" name="link[]" placeholder="Masukkan link" class="form-control link_list" value="'+value.link+'" /></div><div class="col-4 col-sm-2"><button type="button" name="remove"  class="btn btn-danger  btn_remove"><i class="la la-times"></i></button></div></div>');
                        }
                    });
                }else{
                    $("#editLinks").append('<div class="row mb-1 additional-category"> <div class="col-4"> <input type="text" name="judul[]" placeholder="Masukkan judul" class="form-control judul_list" value="" required/> </div> <div class="col-4"> <input type="text" name="link[]" placeholder="Masukkan link" class="form-control link_list" value="" required/> </div> <div class="col-4"> <button type="button" name="add" class="btn btn-success create_add" style="color:white;"><i class="la la-plus"></i></button> <button type="button" name="remove" id="" class="btn btn-danger btn_remove"><i class="la la-times"></i></button></div> </div>');
                }
                $("#editSongReff").text(response.reff);
                $("#editSongForm").attr("action", "<?php echo e(route('song.index')); ?>/" + id);
                response.song_categories.forEach(function (category) {
                    $(".edit-category[value=\"" + category.category_id + "\"]").prop("checked", true);
                });
                $("#editSongModal").modal();
            })
        });
        $(document).on("click", ".deleteSongButton", function()
        {
            let id = $(this).val();

            $("#deleteSongForm").attr("action", "<?php echo e(route('song.index')); ?>/" + id)
            $("#deleteSongModal").modal();
        });
        $(".submit-button").on("submit", function(){
            $(".submit-button").attr("disabled", true);
            setInterval(function() {
                i = ++i % 4;
                $(".submit-button").text("Diproses"+Array(i+1).join("."));
            }, 1000);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u711889996/domains/demibangsa.com/public_html/lagu-sion/server/resources/views/dashboard/song/index.blade.php ENDPATH**/ ?>