

<?php $__env->startSection('title', 'feedback'); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <div class="content-header-left col-md-6 col-12 breadcrumb-new">
    </div>
    <div class="content-header-right col-md-6 col-12">
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">List feedback</h4>
                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                        <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                        <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                        <li><a data-action="close"><i class="ft-x"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-content collapse show">
                <div class="card-body card-dashboard">
                    <table class="table table-responsive d-xl-table datatable w-100">
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th>Feedback</th>
                                <th>Image</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><span class="d-none"><?php echo e(str_pad(strtotime($feedback->created_at), 12, "0", STR_PAD_LEFT)); ?>|</span> <?php echo e(date('d-m-Y H:i', strtotime($feedback->created_at))); ?></td>
                                    <td> <span class="font-weight-bold text-uppercase"><?php echo e($feedback->from); ?></span> <br> <?php echo e($feedback->body); ?></td>
                                    <td>
                                        <img src="data:image/png;base64, <?php echo e($feedback->image); ?>" alt="Feedback Image" style="height: 100px; width: auto !important;">
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $('.datatable').DataTable().destroy();


    $(".datatable").DataTable({
        "order": [[0, "desc"]],
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u711889996/domains/demibangsa.com/public_html/lagu-sion/server/resources/views/dashboard/feedback/index.blade.php ENDPATH**/ ?>