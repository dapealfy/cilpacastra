

<?php $__env->startSection('title', 'Ibadah'); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <div class="content-header-left col-md-6 col-12 breadcrumb-new">
    </div>
    <div class="content-header-right col-md-6 col-12 text-right">
        <div class="btn-group float-md-right">
            <button class="btn btn-warning rounded-0" id="createIbadahButton" type="button">Tambah</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mt-2">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">List Ibadah</h4>
                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                        <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                        <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                        <li><a data-action="close"><i class="ft-x"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-content collapse show">
                <div class="card-body card-dashboard">
                    <table class="table table-responsive d-xl-table ibadah-table w-100">
                        <thead>
                            <tr>
                                <th width="15%">Tanggal</th>
                                <th width="20%" class="text-center">Thumbail</th>
                                <th>Ibadah</th>
                                <th width="10%" class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $ibadahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ibadah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><span class="d-none"><?php echo e($ibadah->ibadah_date); ?></span><?php echo e(date('d-m-Y', strtotime($ibadah->ibadah_date))); ?></td>
                                    <td>
                                        <a href="<?php echo e($ibadah->thumbnail); ?>" target="_blank">
                                            <img src="<?php echo e($ibadah->thumbnail); ?>"  alt="" style="width: auto; height: 100px;">
                                        </a>
                                    </td>
                                    <td><?php echo e($ibadah->ibadah_name ?? '-'); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <a class="btn btn-sm btn-warning" href="<?php echo e(route('ibadah.show', $ibadah->id)); ?>">Lihat
                                            </a>
                                            <button class="btn btn-sm btn-info editIbadahButton" value="<?php echo e($ibadah->id); ?>">Edit
                                            </button>
                                            <button class="btn btn-sm btn-danger deleteIbadahButton" value="<?php echo e($ibadah->id); ?>">Hapus
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="createIbadahModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Tambah Ibadah</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="<?php echo e(route('ibadah.store')); ?>" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="">Tanggal</label>
                        <input type="date" name="ibadah_date" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="">Thumbnail</label>
                        <input type="file" name="thumbnail" class="form-control" accept="image/*">
                    </div>
                    <div class="form-group">
                        <label for="">Ibadah</label>
                        <input type="text" name="ibadah_name" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-warning submit-button">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="editIbadahModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Edit Ibadah</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="" id="editIbadahForm" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("PUT"); ?>
                    <div class="form-group">
                        <label for="">Tanggal</label>
                        <input type="date" name="ibadah_date" class="form-control" id="editIbadahDate" required>
                    </div>
                    <div class="form-group">
                        <img style="height: 100px; width: auto;" id="editThumbnailPreview">
                    </div>
                    <div class="form-group">
                        <label for="">Thumbnail</label>
                        <input type="file" name="thumbnail" class="form-control" accept="image/*" id="editThumbnail">
                    </div>
                    <div class="form-group">
                        <label for="">Ibadah</label>
                        <input type="text" name="ibadah_name" class="form-control" required id="editIbadahName">
                    </div>
    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-warning submit-button">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="deleteIbadahModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Yakin ingin menghapus data Ibadah?</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="" id="deleteIbadahForm" method="post">
                <div class="modal-footer">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("DELETE"); ?>
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-danger">Ya, Hapus</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(".ibadah-table").DataTable({
            "order": [[0, "desc"]]
        });
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                
                reader.onload = function(e) {
                    $('#editThumbnailPreview').attr('src', e.target.result);
                }
                
                reader.readAsDataURL(input.files[0]); // convert to base64 string
            }
        }

        $("#editThumbnail").change(function() {
            readURL(this);
        });
        $(".album-select").select2({
            width: '100%'
        });
        $(document).on("click", "#createIbadahButton", function ()
        {
            $("#createIbadahModal").modal();
        });
        $(document).on("click", ".editIbadahButton", function()
        {
            let id = $(this).val();

            $.ajax(
            {
                method: "GET",
                url: "<?php echo e(route('ibadah.index')); ?>/" + id + "/edit"
            }).done(function (response)
            {
                $("#editThumbnailPreview").attr("src", response.thumbnail);
                $("#editIbadahDate").val(response.ibadah_date);
                $("#editIbadahName").val(response.ibadah_name);
                $("#editIbadahForm").attr("action", "<?php echo e(route('ibadah.index')); ?>/" + id);
                $("#editIbadahModal").modal();
            })
        });
        $(document).on("click", ".deleteIbadahButton", function()
        {
            let id = $(this).val();

            $("#deleteIbadahForm").attr("action", "<?php echo e(route('ibadah.index')); ?>/" + id)
            $("#deleteIbadahModal").modal();
        });
        $(".submit-button").on("submit", function(){
            $(".submit-button").attr("disabled", true);
            setInterval(function() {
                i = ++i % 4;
                $(".submit-button").text("Diproses"+Array(i+1).join("."));
            }, 1000);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u711889996/domains/demibangsa.com/public_html/lagu-sion/server/resources/views/dashboard/ibadah/index.blade.php ENDPATH**/ ?>