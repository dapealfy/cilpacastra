<?php $__env->startSection('title', 'Lagu'); ?>

<?php $__env->startSection('style'); ?>
    <style>
        pre{
            font-family: 'Open Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;
            font-size: 1rem;
            font-weight: 400;
            line-height: 1.45;
            background: none;
            white-space: pre-wrap;
            white-space: -moz-pre-wrap;
            white-space: -pre-wrap;
            white-space: -o-pre-wrap;
            word-wrap: break-word;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Informasi Lagu</h4>
                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-content collapse show">
                <div class="card-body card-dashboard">
                    <div class="row">
                        <div class="col-md-5 text-center">
                            <a href="<?php echo e($song->thumbnail); ?>" target="_blank">
                                <img src="<?php echo e($song->thumbnail); ?>" class="w-100 mb-2">
                            </a>
                            <a href="<?php echo e($song->musical_notes); ?>" class="btn btn-info block rounded-0 text-center mb-1" target="_blank">
                                Lihat Not Balok
                            </a>
                        </div>
                        <div class="col-12 col-md-7">
                            <table class="w-100">
                                <tr>
                                    <td class="w-25">Judul Lagu:</td>
                                    <td>
                                        <?php echo e($song->index != null ? $song->index . '.' : ''); ?> <?php echo e($song->title); ?>

                                    </td>
                                </tr>          
                                <tr>
                                    <td class="w-25">Artis:</td>
                                    <td><?php echo e($song->artist); ?></td>
                                </tr>
                                <tr>
                                    <td class="w-25">Album:</td>
                                    <td><?php echo e($song->album->album_name); ?></td>
                                </tr>
                                <tr>
                                    <td class="w-25">Not Dasar:</td>
                                    <td><?php echo e($song->basic_notes); ?></td>
                                </tr>
                                <tr>
                                    <td class="w-25">Durasi:</td>
                                    <td><?php echo e($song->duration); ?></td>
                                </tr>
                                <tr>
                                    <td class="w-25">Link Cerita:</td>
                                    <?php if($song->story_link != null): ?>
                                        <td>
                                            <a href="<?php echo e($song->story_link); ?>">
                                                <?php echo e($song->story_link); ?>

                                            </a>
                                        </td>
                                    <?php else: ?>
                                        <td>-</td>
                                    <?php endif; ?>
                                </tr>
                                <tr>
                                    <td class="w-25" style="vertical-align: top">Cerita:</td>
                                    <td>
                                        <pre><?php echo e($song->story); ?></pre>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-12">
        <div class="row">
            <div class="col-12 text-right">
                <div class="btn-group float-md-right">
                    <button class="btn btn-warning rounded-0 mb-1" id="createVerseOneButton" type="button">Tambah Bait</button>
                </div>
            </div>
        </div>
        <div class="card mt-1">
            <div class="card-header">
                <h4 class="card-title">Lirik</h4>
                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-content collapse show">
                <div class="card-body card-dashboard">
                    <table class="table table-striped table-responsive w-100">
                        <thead>
                            <tr>
                                <th class="w-25 text-center">Waktu Tampil</th>
                                <th class="text-center w-50">Bait</th>
                                <th width="10%" class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $song->verses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyVerse => $verse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center">
                                        <?php echo e($verse->duration); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php if($verse->part != null): ?>
                                            <p class="badge badge-warning font-weight-bold text-uppercase" style="font-size: 14px"><?php echo e($keyVerse+1); ?></p>
                                        <?php endif; ?>
                                        <pre><?php echo e($verse->lyrics); ?></pre>
                                    </td>
                                    <td class="text-center">
                                        <div class="btn-group">
                                            <button class="btn btn-sm btn-info <?php echo e($verse->part == null ? 'editVerseOneButton' : 'disabled'); ?>" value="<?php echo e($verse->id); ?>">Edit
                                            </button>
                                            <button class="btn btn-sm btn-danger deleteVerseOneButton" value="<?php echo e($verse->id); ?>">Hapus
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-12 col-md-6">
        <div class="row">
            <div class="col-12 text-right">
                <div class="btn-group float-md-right">
                    <button class="btn btn-warning rounded-0 mb-1" id="createInstrumentButton" type="button">Tambah</button>
                </div>
            </div>
        </div>
        <div class="card mt-1">
            <div class="card-header">
                <h4 class="card-title">Instrumen</h4>
                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-content collapse show">
                <div class="card-body card-dashboard">
                    <table class="table table-responsive datatable w-100">
                        <thead>
                            <tr>
                                <th>Kategori</th>
                                <th style="min-width: 80px !important; max-width: 128px !important;">Notes</th>
                                <th width="10%">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $song_versions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song_version): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-nowrap">
                                        <a href="<?php echo e($song_version->file); ?>" target="_blank">
                                            <?php echo e($song_version->version_name); ?><?php echo e($song_version->song_category->index == 2 ? ' (lagu utama)' : ''); ?>

                                        </a>
                                    </td>
                                    <td>
                                        <p><?php echo e($song_version->notes); ?></p>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <button class="btn btn-sm btn-info editInstrumentButton" value="<?php echo e($song_version->id); ?>">Edit
                                            </button>
                                            <button class="btn btn-sm btn-danger deleteInstrumentButton" value="<?php echo e($song_version->id); ?>">Hapus
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-md-6">
        <div class="row">
            <div class="col-12 text-right">
                <div class="btn-group float-md-right">
                    <button class="btn btn-warning rounded-0 mb-1" id="createCorrelationButton" type="button">Tambah</button>
                </div>
            </div>
        </div>
        <div class="card mt-1">
            <div class="card-header">
                <h4 class="card-title">Korelasi Lagu</h4>
                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-content collapse show">
                <div class="card-body card-dashboard">
                    <table class="table table-responsive d-xl-table datatable w-100">
                        <thead>
                            <tr>
                                <th>Judul Lagu</th>
                                <th width="10%">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $song->correlations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $correlation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <a href="<?php echo e(route('song.show', $correlation->id)); ?>" target="_blank">
                                            <?php echo e($correlation->index != null ? $correlation->index . '.' : ''); ?> <?php echo e($correlation->title); ?>

                                        </a>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-danger deleteCorrelationButton" value="<?php echo e($correlation->id); ?>">Hapus
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>

<div class="modal fade" id="createInstrumentModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Tambah Instrumen</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="<?php echo e(route('song-version.store')); ?>" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="song_id" value="<?php echo e($song->id); ?>">
                    <div class="form-group">
                        <label for="">Kategori Lagu</label>
                        <select name="song_category_id" class="form-control">
                            <?php $__currentLoopData = $song_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $song_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($song_category->id); ?>"><?php echo e($song_category->name); ?><?php echo e($song_category->index == 2 ? ' (lagu utama)' : ''); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Notes</label>
                        <textarea name="notes" class="form-control"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="">File</label>
                        <input type="file" name="file" class="form-control" accept="audio/*">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-warning">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="editInstrumentModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Edit Instrumen</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="" id="editInstrumentForm" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("PUT"); ?>
                    <input type="hidden" name="song_id" value="<?php echo e($song->id); ?>">
                    <div class="form-group">
                        <label for="">Kategori Lagu</label>
                        <select name="song_category_id" class="form-control" id="editSongCategoryId">
                            <?php $__currentLoopData = $song_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $song_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($song_category->id); ?>"><?php echo e($song_category->name); ?><?php echo e($song_category->index == 2 ? ' (lagu utama)' : ''); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Notes</label>
                        <textarea name="notes" class="form-control" id="editNotes"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="">File</label>
                        <input type="file" name="file" class="form-control" accept="audio/*">
                        <small class="text-danger">*Isi jika ingin mengubah file musik</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-warning">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="deleteInstrumentModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Yakin ingin menghapus Lagu?</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="" id="deleteInstrumentForm" method="post">
                <div class="modal-footer">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("DELETE"); ?>
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-danger">Ya, Hapus</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="createVerseOneModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Tambah Bait Lirik</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="<?php echo e(route('verse.store')); ?>" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="song_id" value="<?php echo e($song->id); ?>">
                    <div class="form-group">
                        <label for="">Waktu muncul (detik)</label>
                        <div class="row h-100">
                            <div class="col-md-3 col-5">
                                <input type="text" name="duration[0]" class="form-control input-number" minlength="2" maxlength="2" placeholder="00" required>
                            </div>
                            <div class="col-1 my-auto">
                                <span>:</span>
                            </div>
                            <div class="col-md-3 col-5">
                                <input type="text" name="duration[1]" class="form-control input-number" minlength="2" maxlength="2" placeholder="00" required>
                            </div>
                        </div>
                        <!--<small class="danger">Akan dikonversi otomatis ke format MM:ss. Contoh: 128 dikonversi menjadi 02:08</small>-->
                    </div>
                    <div class="form-group">
                        <label for="">Bait</label>
                        <textarea name="lyrics" class="form-control" required></textarea>
                    </div>
                    <div class="form-group d-none">
                        <label for="">Apakah bait ini bagian reff ?</label>
                        <br>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="part" value="reff">
                            <label class="form-check-label">Ya</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="part" value="" checked>
                            <label class="form-check-label">Tidak</label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-warning">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="editVerseOneModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Edit Bait Lirik Default</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="" id="editVerseOneForm" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("PUT"); ?>
                    <input type="hidden" name="song_id" value="<?php echo e($song->id); ?>">
                    <div class="form-group">
                        <label for="">Waktu muncul (detik)</label>
                        <div class="row">
                            <div class="col-md-3 col-5">
                                <input type="text" name="duration[0]" class="form-control input-number" minlength="2" maxlength="2" placeholder="00" onchange="if(parseInt(this.value,10)<10)this.value='0'+this.value;" id="editDurationOne" required>
                            </div>
                            <div class="col-1 my-auto">
                                <span>:</span>
                            </div>
                            <div class="col-md-3 col-5">
                                <input type="text" name="duration[1]" class="form-control input-number" minlength="2" maxlength="2" placeholder="00" onchange="if(parseInt(this.value,10)<10)this.value='0'+this.value;" id="editDurationTwo" required>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="">Bait</label>
                        <textarea name="lyrics" class="form-control" id="editVerseOneLyrics" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="">Apakah bait ini bagian reff ?</label>
                        <br>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input editPart" type="radio" name="part" value="reff">
                            <label class="form-check-label">Ya</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input editPart" type="radio" name="part" value="" checked>
                            <label class="form-check-label">Tidak</label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-warning">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="deleteVerseOneModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Yakin ingin menghapus bait?</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="" id="deleteVerseOneForm" method="post">
                <div class="modal-footer">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("DELETE"); ?>
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-danger">Ya, Hapus</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="createCorrelationModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Tambah Korelasi Lagu</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="<?php echo e(route('song.store-correlation')); ?>" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="song_id" value="<?php echo e($song->id); ?>">
                    <div class="form-group">
                        <label for="">Judul Lagu</label>
                        <select name="correlation_song_id" class="form-control song-title" style="width: 100% !important;">
                            <option></option>
                            <?php $__currentLoopData = $songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $other_song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option class="<?php echo e($other_song->id); ?>"><?php echo e($other_song->index != null ? $other_song->index . '. ' . $other_song->title : $other_song->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-warning">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="deleteCorrelationModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Yakin ingin menghapus korelasi lagu?</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="" id="deleteCorrelationForm" method="post">
                <div class="modal-footer">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("DELETE"); ?>
                    
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-danger" name="correlation_song_id" id="deleteCorrelationId">Ya, Hapus</button>
                </div>
            </form>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(".song-title").select2({
            placeholder: "Silahkan pilih lagu",
            allowClear: true
        });
        $(document).on("click", '#createCorrelationButton', function()
        {
            $("#createCorrelationModal").modal();
        });
        $(document).on("click", "#createInstrumentButton", function ()
        {
            $("#createInstrumentModal").modal();
        });
        $(document).on("click", ".deleteCorrelationButton", function ()
        {
            var id = $(this).val();
            $("#deleteCorrelationForm").attr("action", "/song/destroy-correlation/" + id);
            $("#deleteCorrelationModal").modal();
        });
        $(document).on("click", ".editInstrumentButton", function()
        {
            let id = $(this).val();

            $.ajax(
            {
                method: "GET",
                url: "<?php echo e(route('song-version.index')); ?>/" + id + "/edit"
            }).done(function (response)
            {
                console.log(response);
                $("#editSongCategoryId").val(response.song_category_id).trigger("change");
                $("#editNotes").text(response.notes);
                $("#editInstrumentForm").attr("action", "<?php echo e(route('song-version.index')); ?>/" + id)
                $("#editInstrumentModal").modal();
            })
        });
        
        $(document).on("click", ".deleteInstrumentButton", function()
        {
            let id = $(this).val();

            $("#deleteInstrumentForm").attr("action", "<?php echo e(route('song-version.index')); ?>/" + id)
            $("#deleteInstrumentModal").modal();
        });

        $(document).on("click", "#createVerseOneButton", function ()
        {
            $("#createVerseOneModal").modal();
        });
        
        $(document).on("click", ".editVerseOneButton", function()
        {
            let id = $(this).val();

            $.ajax(
            {
                method: "GET",
                url: "<?php echo e(route('verse.index')); ?>/" + id + "/edit"
            }).done(function (response)
            {
                $("#editDurationOne").val(response.duration[0]);
                $("#editDurationTwo").val(response.duration[1]);
                $(".editPart[value='" + response.part + "']").prop('checked', true);
                $("#editVerseOneLyrics").text(response.lyrics);
                $("#editVerseOneForm").attr("action", "<?php echo e(route('verse.index')); ?>/" + id)
                $("#editVerseOneModal").modal();
            })
        });
        
        $(document).on("click", ".deleteVerseOneButton", function()
        {
            let id = $(this).val();

            $("#deleteVerseOneForm").attr("action", "<?php echo e(route('verse.index')); ?>/" + id)
            $("#deleteVerseOneModal").modal();
        });
        $(document).on("keypress", ".input-number", function(evt) { 
                  
            // Only ASCII charactar in that range allowed 
            var ASCIICode = (evt.which) ? evt.which : evt.keyCode 
            if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57)) 
                return false; 
            return true; 
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u711889996/domains/demibangsa.com/public_html/lagu-sion/server/resources/views/dashboard/song/show.blade.php ENDPATH**/ ?>