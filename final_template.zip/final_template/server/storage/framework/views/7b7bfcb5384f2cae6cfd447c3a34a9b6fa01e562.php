

<?php $__env->startSection('title', 'Audio Book'); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <div class="content-header-left col-md-6 col-12 breadcrumb-new">
    </div>
    <div class="content-header-right col-md-6 col-12 text-right">
        <div class="btn-group float-md-right">
            <button class="btn btn-warning rounded-0" id="createAudioBookButton" type="button">Tambah</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mt-2">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">List Audio Book</h4>
                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                        <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                        <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                        <li><a data-action="close"><i class="ft-x"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-content collapse show">
                <div class="card-body card-dashboard">
                    <table class="table table-responsive d-xl-table datatable w-100">
                        <thead>
                            <tr>
                                <th>Thumbail</th>
                                <th>Audio Book</th>
                                <th width="10%" class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $audio_books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audio_book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <a href="<?php echo e($audio_book->thumbnail); ?>" target="_blank">
                                            <img src="<?php echo e($audio_book->thumbnail); ?>"  alt="" style="width: auto; height: 100px;">
                                        </a>
                                    </td>
                                    <td><?php echo e($audio_book->audio_book_name ?? '-'); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <a class="btn btn-sm btn-warning" href="<?php echo e(route('audio-book.show', $audio_book->id)); ?>">Lihat
                                            </a>
                                            <button class="btn btn-sm btn-info editAudioBookButton" value="<?php echo e($audio_book->id); ?>">Edit
                                            </button>
                                            <button class="btn btn-sm btn-danger deleteAudioBookButton" value="<?php echo e($audio_book->id); ?>">Hapus
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="createAudioBookModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Tambah AudioBook</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="<?php echo e(route('audio-book.store')); ?>" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="">Thumbnail</label>
                        <input type="file" name="thumbnail" class="form-control" accept="image/*">
                    </div>
                    <div class="form-group">
                        <label for="">Audio Book</label>
                        <input type="text" name="audio_book_name" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-warning submit-button">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="editAudioBookModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Edit AudioBook</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="" id="editAudioBookForm" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("PUT"); ?>
                    <div class="form-group">
                        <img style="height: 100px; width: auto;" id="editThumbnailPreview">
                    </div>
                    <div class="form-group">
                        <label for="">Thumbnail</label>
                        <input type="file" name="thumbnail" class="form-control" accept="image/*" id="editThumbnail">
                    </div>
                    <div class="form-group">
                        <label for="">Audio Book</label>
                        <input type="text" name="audio_book_name" class="form-control" required id="editAudioBookName">
                    </div>
    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-warning submit-button">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="deleteAudioBookModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Yakin ingin menghapus data AudioBook?</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="" id="deleteAudioBookForm" method="post">
                <div class="modal-footer">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("DELETE"); ?>
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-danger">Ya, Hapus</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                
                reader.onload = function(e) {
                    $('#editThumbnailPreview').attr('src', e.target.result);
                }
                
                reader.readAsDataURL(input.files[0]); // convert to base64 string
            }
        }

        $("#editThumbnail").change(function() {
            readURL(this);
        });
        $(".album-select").select2({
            width: '100%'
        });
        $(document).on("click", "#createAudioBookButton", function ()
        {
            $("#createAudioBookModal").modal();
        });
        $(document).on("click", ".editAudioBookButton", function()
        {
            let id = $(this).val();

            $.ajax(
            {
                method: "GET",
                url: "<?php echo e(route('audio-book.index')); ?>/" + id + "/edit"
            }).done(function (response)
            {
                $("#editThumbnailPreview").attr("src", response.thumbnail);
                $("#editAudioBookName").val(response.audio_book_name);
                $("#editAudioBookForm").attr("action", "<?php echo e(route('audio-book.index')); ?>/" + id);
                $("#editAudioBookModal").modal();
            })
        });
        $(document).on("click", ".deleteAudioBookButton", function()
        {
            let id = $(this).val();

            $("#deleteAudioBookForm").attr("action", "<?php echo e(route('audio-book.index')); ?>/" + id)
            $("#deleteAudioBookModal").modal();
        });
        $(".submit-button").on("submit", function(){
            $(".submit-button").attr("disabled", true);
            setInterval(function() {
                i = ++i % 4;
                $(".submit-button").text("Diproses"+Array(i+1).join("."));
            }, 1000);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u711889996/domains/demibangsa.com/public_html/lagu-sion/server/resources/views/dashboard/audio_book/index.blade.php ENDPATH**/ ?>