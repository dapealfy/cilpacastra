

<?php $__env->startSection('title', 'Ibadah'); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <div class="content-header-left col-md-6 col-12 breadcrumb-new">
    </div>
    <div class="content-header-right col-md-6 col-12 text-right">
        <div class="btn-group float-md-right">
            <button class="btn btn-warning rounded-0" id="createIbadahPartButton" type="button">Tambah</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mt-2">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">List Ibadah Part</h4>
                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                        <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                        <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                        <li><a data-action="close"><i class="ft-x"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-content collapse show">
                <div class="card-body card-dashboard">
                    <p class="card-text">Berikut adalah list dari beberapa Ibadah Part dari Ibadah <span class="font-weight-bold"><?php echo e($ibadah->ibadah_name); ?></span></p>
                    <table class="table table-responsive d-xl-table datatable w-100">
                        <thead>
                            <tr>
                                <th>Thumbnail</th>
                                <th>Nama Ibadah Part</th>
                                <th>Durasi</th>
                                <th>Teks</th>
                                <th width="10%" class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $ibadah->parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ibadah_part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <a href="<?php echo e($ibadah_part->thumbnail); ?>" target="_blank">
                                            <img src="<?php echo e($ibadah_part->thumbnail); ?>" height="128px" width="auto">
                                        </a>
                                    </td>
                                    <td>
                                        <a href="<?php echo e($ibadah_part->music); ?>" target="_blank">
                                            <?php echo e($ibadah_part->title); ?>

                                        </a>
                                    </td>
                                    <td><?php echo e($ibadah_part->duration); ?></td>
                                    <td>
                                        <div style="height: 128px; overflow-y: scroll; ">
                                            <pre style="white-space: pre-wrap; white-space: -moz-pre-wrap; white-space: -pre-wrap; white-space: -o-pre-wrap; word-wrap: break-word; background: none; font-size: 14px"><?php echo e($ibadah_part->lyrics); ?></pre>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <button class="btn btn-sm btn-info editIbadahPartButton" value="<?php echo e($ibadah_part->id); ?>">Edit
                                            </button>
                                            <button class="btn btn-sm btn-danger deleteIbadahPartButton" value="<?php echo e($ibadah_part->id); ?>">Hapus
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="createIbadahPartModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Tambah Ibadah</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="<?php echo e(route('ibadah-part.store')); ?>" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="ibadah_id" value="<?php echo e($ibadah->id); ?>">
                    <div class="form-group">
                        <label for="">Nama Ibadah Part</label>
                        <input type="text" name="title" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="">Teks</label>
                        <textarea name="lyrics" class="form-control" rows="5" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="">File</label>
                        <input type="file" name="music" class="form-control" accept="audio/*">
                    </div>
                    <div class="form-group">
                        <label for="">Thumbnail</label>
                        <input type="file" name="thumbnail" class="form-control" accept="image/*">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-warning">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="editIbadahPartModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Edit Ibadah</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="" id="editIbadahPartForm" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("PUT"); ?>
                    <input type="hidden" name="ibadah_id" value="<?php echo e($ibadah->id); ?>">
                    <div class="form-group">
                        <label for="">Judul Ibadah</label>
                        <input type="text" name="title" class="form-control" id="editIbadahPartTitle" required>
                    </div>
                    <div class="form-group">
                        <label for="">Teks</label>
                        <textarea name="lyrics" class="form-control" rows="5" id="editIbadahPartLyrics" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="">Musik</label>
                        <input type="file" name="music" class="form-control" accept="audio/*">
                        <small class="text-danger">*Isi jika ingin mengubah musik</small>
                    </div>
                    <div class="form-group">
                        <label for="">Thumbnail</label>
                        <br>
                        <input type="file" name="thumbnail" class="form-control" accept="image/*">
                        <small class="text-danger">*Isi jika ingin mengubah thumbnail</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-warning">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="deleteIbadahPartModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning white">
                <h4 class="modal-title white">Yakin ingin menghapus Ibadah?</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="" id="deleteIbadahPartForm" method="post">
                <div class="modal-footer">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("DELETE"); ?>
                    <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-outline-danger">Ya, Hapus</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).on("click", "#createIbadahPartButton", function ()
        {
            $("#createIbadahPartModal").modal();
        });
        $(document).on("click", ".editIbadahPartButton", function()
        {
            let id = $(this).val();

            $.ajax(
            {
                method: "GET",
                url: "<?php echo e(route('ibadah-part.index')); ?>/" + id + "/edit"
            }).done(function (response)
            {
                $("#editIbadahPartTitle").val(response.title);
                $("#editIbadahPartLyrics").val(response.lyrics);
                $("#editIbadahPartForm").attr("action", "<?php echo e(route('ibadah-part.index')); ?>/" + id)
                $("#editIbadahPartModal").modal();
            })
        });
        $(document).on("click", ".deleteIbadahPartButton", function()
        {
            let id = $(this).val();

            $("#deleteIbadahPartForm").attr("action", "<?php echo e(route('ibadah-part.index')); ?>/" + id)
            $("#deleteIbadahPartModal").modal();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u711889996/domains/demibangsa.com/public_html/lagu-sion/server/resources/views/dashboard/ibadah/show.blade.php ENDPATH**/ ?>