<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;

class UserController extends Controller
{
    public function index()
    {
        $data['users'] = User::all();
        
        return view('dashboard.user.index', $data);
    }
    
    public function store(Request $request)
    {
        $avatarPath = url('/') . '/app-assets/images/default.png';
        if ($request->hasFile('avatar')) {
            $avatar = request()->file('avatar');
            $avatar->store('/public/avatar');
            $filename = $avatar->hashName();
            $avatarPath = url('/') . '/storage/avatar/' . $filename;
        }
        User::create([
            'role' => 'admin',
            'name' => $request->name,
            'username' => $request->username,
            'password' => bcrypt($request->password),
            'avatar' => $avatarPath
        ]);
        
        return redirect()->back()->with('OK', 'Berhasil menambah data');
    }
    
    public function edit($id)
    {
        $user = User::find($id);
        
        return $user;
    }
    
    public function update(Request $request, $id)
    {
        $user = User::find($id);
        $password = $user->password;
        if($request->password != '' && $request->password != null)
        {
            $password = bcrypt($request->password);
        }
        $avatarPath = $user->avatar;
        if ($request->hasFile('avatar')) {
            $avatar = request()->file('avatar');
            $avatar->store('/public/avatar');
            $filename = $avatar->hashName();
            $avatarPath = url('/') . '/storage/avatar/' . $filename;
        }
        $user->update([
            'role' => 'admin',
            'name' => $request->name,
            'username' => $request->username,
            'password' => $password,
            'avatar' => $avatarPath
        ]);
        
        return redirect()->back()->with('OK', 'Berhasil mengedit data');
    }
    
    public function destroy($id)
    {
        $user = User::find($id);
        $user->delete();   
     
        return redirect()->back()->with('OK', 'Berhasil menghapus data');
    }
}
